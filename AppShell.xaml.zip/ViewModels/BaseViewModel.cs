﻿namespace TheWatch.ViewModels;

public partial class BaseViewModel : ObservableObject
{
}
