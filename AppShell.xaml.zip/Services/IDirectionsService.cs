﻿namespace TheWatch.Services;

public interface IDirectionsService
{
    
}

public class DirectionsService : IDirectionsService
{
    
}