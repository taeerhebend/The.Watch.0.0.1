﻿namespace TheWatch.Models;

public class Evacuation
{
    
}