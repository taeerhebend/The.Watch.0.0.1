﻿namespace TheWatch.Models;

public class FirstResponseOrganization
{
    [JsonProperty(PropertyName = "id", NullValueHandling = NullValueHandling.Ignore)]
    public string Id { get; set; }
        
}