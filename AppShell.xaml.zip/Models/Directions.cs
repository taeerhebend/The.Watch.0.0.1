﻿namespace TheWatch.Models;

public class Directions
{
    
}