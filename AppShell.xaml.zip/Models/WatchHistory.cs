﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheWatch.Models
{
    public class WatchHistory
    {
        public List<WatchCall> WatchCalls { get; set; }
    }

}
