﻿namespace TheWatch.Models;

public class Map
{
    
}