﻿namespace TheWatch.Models;

public class CheckIn
{
    
}