﻿global using Newtonsoft.Json;
global using TheWatch.Models;
